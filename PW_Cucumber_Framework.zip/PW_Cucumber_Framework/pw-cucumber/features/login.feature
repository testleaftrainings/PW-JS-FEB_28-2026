Feature: Login

  Background:
    Given the user is on the login page

  Scenario: Successful login with valid credentials
    When the user enters valid credentials
    And the user clicks the login button
    Then the user should see the dashboard
