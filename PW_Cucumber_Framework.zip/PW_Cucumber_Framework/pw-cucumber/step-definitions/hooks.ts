import { Before, After, setDefaultTimeout } from '@cucumber/cucumber';
import { chromium, Browser, Page } from 'playwright';

setDefaultTimeout(60 * 1000); // 60s default timeout

Before(async function (this: any) {
  // launch browser and new page before each scenario
  this.browser = await chromium.launch({ headless: false }); // set headless: true for CI
  this.page = await this.browser.newPage();
});

After(async function (this: any) {
  // cleanup
  if (this.page) await this.page.close();
  if (this.browser) await this.browser.close();
});
