import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from 'chai';

Given('the user is on the login page', async function (this: any) {
  const url = 'https://example.com/login'; // change to your app
  await this.page.goto(url);
});

When('the user enters valid credentials', async function (this: any) {
  // Replace selectors and credentials with real ones
  await this.page.fill("input[name='username']", 'testuser');
  await this.page.fill("input[name='password']", 'Test@1234');
});

When('the user clicks the login button', async function (this: any) {
  await this.page.click("button[type='submit']");
  // optionally wait for navigation
  await this.page.waitForLoadState('networkidle');
});

Then('the user should see the dashboard', async function (this: any) {
  // Example assertion: page title contains 'Dashboard' or a dashboard selector is visible
  const title = await this.page.title();
  expect(title).to.include('Dashboard');
  // or: await this.page.waitForSelector('#dashboard-welcome', { timeout: 5000 });
});
